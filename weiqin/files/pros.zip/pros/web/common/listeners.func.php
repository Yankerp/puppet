<?php
/**
 * @package     ${NAMESPACE}
 * @subpackage
 *
 * @copyright   A copyright
 * @license     A "Slug" license name e.g. GPL2
 */

defined('IN_IA') or exit('Access Denied');


/* @var $event EventDispather */
//$event = $_W['event'];
//
//$event->add('hello', function ($args){
////	print_r($args);
//	return false;
//});
//
//$event->add('hello', function ($args){
////	print_r($args);
//});
//
//$event->fire('hello', 'helloevents');

