<?php

namespace We7\V202;

defined('IN_IA') or exit('Access Denied');
/**
 * [WeEngine System] Copyright (c) 2014 W7.CC
 * Time: 1552556483
 * @version 2.0.2
 */

class UpgradeUniSettings {

	/**
	 *  执行更新
	 */
	public function up() {
		pdo_update('users', array('founder_groupid' => 1), array('uid' => 1));
	}
	
	/**
	 *  回滚更新
	 */
	public function down() {
		

	}
}
		