<?php

namespace We7\V180;

defined('IN_IA') or exit('Access Denied');
/**
 * [WeEngine System] Copyright (c) 2014 W7.CC
 * Time: 1533090436
 * @version 1.8.0
 */

class UpgradeModules {

	/**
	 *  执行更新
	 */
	public function up() {
		if (!pdo_fieldexists('modules', 'aliapp_support')) {
			pdo_query("ALTER TABLE " . tablename('modules') . " ADD `aliapp_support` tinyint(1) DEFAULT 1 NOT NULL;");
		}
	}
	
	/**
	 *  回滚更新
	 */
	public function down() {
		

	}
}
		