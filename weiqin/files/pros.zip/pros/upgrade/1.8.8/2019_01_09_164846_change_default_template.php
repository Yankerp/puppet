<?php

namespace We7\V188;

defined('IN_IA') or exit('Access Denied');
/**
 * [WeEngine System] Copyright (c) 2014 W7.CC
 * Time: 1546505315
 * @version 1.8.8
 */

class DeleteUnusedFile {

	/**
	 *  执行更新
	 */
	public function up() {
		if (IMS_FAMILY != 'l') {
			setting_save(array('template' => '2.0'), 'basic');
		}
	}
	
	/**
	 *  回滚更新
	 */
	public function down() {
		

	}
}
		