<?php

/**
 * [WeEngine System] Copyright (c) 2013 WE7.CC
 * User: fanyk
 * Date: 2018/1/6
 * Time: 10:30
 */
class ModulebindingTable extends We7Table {

	protected $tableName = 'modules_bindings';


}