<?php
/**
 * [WeEngine System] Copyright (c) 2013 WE7.CC
 * User: fanyk
 * Date: 2017/12/26
 * Time: 17:14
 */
class BaseaccountTable extends We7Table  {

	protected $tableName = 'account';
	protected $primaryKey = 'acid';



}