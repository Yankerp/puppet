<?php
/**
 *
 * [WeEngine System] Copyright (c) 2013 WE7.CC
 */

defined('IN_IA') or exit('Access Denied');
class RulekeywordTable extends We7Table {
	protected $tableName = 'rule_keyword';
	protected $field = array('rid', 'uniacid', 'module', 'module', 'content', 'type', 'displayorder', 'status');
}